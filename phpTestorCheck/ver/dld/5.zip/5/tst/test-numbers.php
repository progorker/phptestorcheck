<?php
function test_numbers( $p_token, $p_suite_id ) {
  $v_case_code = 'test_numbers';
  $v_case_id = -1;
  \phptestor\api_testor_case( $p_token, $v_case_id, $p_suite_id, $v_case_code );

  $v_test_code = 'equals.1';
  $v_test_id = -1;
  $v_num_a = 30.3;
  $v_num_b = 30.3;
  \phptestor\api_testor_equals( $p_token, $v_test_id, $p_suite_id, $v_case_id, $v_test_code, $v_num_a, $v_num_b );

}
?>